<template>
  <div class="VueAppAboutView">
    VueAppAboutView
  </div>
</template>

<script>
export default {
  name: 'VueAppAboutView',

  data() {
    return {
      
    };
  },

  mounted() {
    
  },

  methods: {
    
  },
};
</script>

<style lang="scss" scoped>

</style>