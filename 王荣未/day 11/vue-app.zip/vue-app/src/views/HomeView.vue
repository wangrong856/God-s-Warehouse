<template>
  <div class="VueAppHomeView">
    <p class="header">tabBar案例</p>
    <my-tab :arr="arr">
      <template #delBtn="{ t }">
        <div>
          <button class="delBtn" @click="delGoods(t)">删除</button>
        </div>
      </template>
      <template #tagSlot="{ t, i }">
        <div>
          <div class="tag" v-show="!t.flag" @click="switchTag(t, i)">+Tag</div>
          <div class="inp" v-show="t.flag">
            <input
              type="text"
              v-model="t.value"
              v-focus
              @blur="blurInput(t)"
              @keyup.13="keyUp(t)"
            />
          </div>
          <div class="box-tag">
            <span v-for="ite in t.children" :key="ite.tag_id">{{
              ite.goods_tag
            }}</span>
          </div>
        </div>
      </template>
    </my-tab>
  </div>
</template>

<script>
import MyTab from "@/components/MyTab.vue";
export default {
  components: { MyTab },
  name: "VueAppHomeView",

  data() {
    return {
      arr: [
        {
          goods_id: "1",
          goods_name: "Teenmix/，天美意夏季专柜同款金色布女鞋6YF18BT6",
          goods_price: 298,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800480,
              goods_tag: "舒适",
            },
            {
              tag_id: 1669287800481,
              goods_tag: "透气",
            },
          ],
        },
        {
          goods_id: "2",
          goods_name:
            "奥休斯(al‖shoes)冬季保暖女士休闲雪地靴舒适加绒防水短靴防滑棉鞋子",
          goods_price: 89,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800482,
              goods_tag: "保暖",
            },
            {
              tag_id: 1669287800483,
              goods_tag: "防滑",
            },
          ],
        },
        {
          goods_id: "3",
          goods_name: "初语秋冬新款毛衣女套头宽松针织衫简约插肩袖上衣",
          goods_price: 199,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800484,
              goods_tag: "秋冬",
            },
            {
              tag_id: 1669287800485,
              goods_tag: "毛衣",
            },
          ],
        },
        {
          goods_id: "4",
          goods_name:
            "佐露絲蕾丝衫女2020春秋装新款大码女装衬衫上衣雪纺衫韩版打底衫长袖",
          goods_price: 19,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800486,
              goods_tag: "雪纺衫",
            },
            {
              tag_id: 1669287800487,
              goods_tag: "打底",
            },
          ],
        },
        {
          goods_id: "5",
          goods_name:
            "熙世界中长款长袖圆领毛衣女2022秋装新款假两件连衣裙女107SL170",
          goods_price: 178,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800488,
              goods_tag: "圆领",
            },
            {
              tag_id: 1669287800489,
              goods_tag: "连衣裙",
            },
          ],
        },
        {
          goods_id: "6",
          goods_name:
            "烟花烫2021秋季装新品女装简约修身显瘦七分袖欧根纱连衣裙花央",
          goods_price: 282,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800489,
              goods_tag: "秋季新品",
            },
            {
              tag_id: 1669287800490,
              goods_tag: "显瘦",
            },
          ],
          goods_tag: " ",
        },
        {
          goods_id: "7",
          goods_name:
            "韩都衣舍2021韩版女装秋装新宽松显瘦纯色系带长袖对衫NG8201",
          goods_price: 128,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800491,
              goods_tag: "韩都衣舍",
            },
            {
              tag_id: 1669287800492,
              goods_tag: "长袖衬衫",
            },
          ],
        },
        {
          goods_id: "8",
          goods_name:
            "预售纤莉秀大码女装胖妹妹秋装2020新款圆领百搭绣花胖mm休闲套头卫衣",
          goods_price: 128,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800493,
              goods_tag: "预售",
            },
            {
              tag_id: 1669287800494,
              goods_tag: "卫衣",
            },
          ],
        },
        {
          goods_id: "9",
          goods_name: "莎密2022夏改良旗袍裙连衣裙修身复古时尚日常短款礼服旗袍",
          goods_price: 128,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800495,
              goods_tag: "莎密",
            },
            {
              tag_id: 1669287800496,
              goods_tag: "礼服",
            },
          ],
          goods_tag: " ",
        },
        {
          goods_id: "10",
          goods_name: "南极人秋冬韩版七彩棉加绒加厚一体保暖打底裤印7011",
          goods_price: 128,
          flag: false,
          value: "",
          children: [
            {
              tag_id: 1669287800497,
              goods_tag: "南极人",
            },
            {
              tag_id: 1669287800498,
              goods_tag: "打底裤",
            },
          ],
        },
      ],
    };
  },

  mounted() {},

  methods: {
    delGoods(t) {
      let index = this.arr.findIndex((ite) => ite.goods_id === t.goods_id);
      this.arr.splice(index, 1);
    },
    switchTag(t, i) {
      t.flag = true;
      // 第二种获取焦点
      // this.$nextTick(() => {
      //   var inp = document.querySelectorAll("input");
      //   inp[i].focus()
      // });
    },
    blurInput(t) {
      t.flag = false;
      this.clearInputValue(t);
    },
    keyUp(t) {
      if (t.value.length == 0) return alert("不能为空");
      t.children.push({
        goods_tag: t.value,
        tag_id: Date.now(),
      });
      this.clearInputValue(t);
    },
    clearInputValue(t) {
      t.value = "";
    },
  },

  directives: {},
};
</script>

<style lang="scss" scoped>
.header {
  line-height: 3.125rem;
  background: rgb(60, 121, 246);
  wgoods_idth: 100%;
  color: #fff;
  text-align: center;
  font-size: 1.0625rem;
}
</style>
