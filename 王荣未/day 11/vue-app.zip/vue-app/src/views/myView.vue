<template>
    <div class="VueAppMyView">
        myView
    </div>
</template>

<script>
export default {
    name: 'VueAppMyView',

    data() {
        return {
            
        };
    },

    mounted() {
        
    },

    methods: {
        
    },
};
</script>

<style lang="scss" scoped>

</style>