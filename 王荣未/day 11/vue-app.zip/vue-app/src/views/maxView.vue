<template>
  <div class="maxView">
    <div class="sheader">
      <router-view></router-view>
    </div>
    <div class="foot">
      <tab-switch></tab-switch>
    </div>
  </div>
</template>

<script>
import tabSwitch from "@/components/tabSwitch.vue";
export default {
  components: { tabSwitch },
  name: "VueAppMaxView",

  data() {
    return {};
  },

  mounted() {},

  methods: {},
};
</script>

<style lang="scss" scoped>
.maxView {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  .sheader {
    width: 100%;
    flex: 1;
  }
  .foot {
    height: 3.125rem;
  }
}
</style>
