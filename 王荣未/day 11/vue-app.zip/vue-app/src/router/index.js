import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: "/", component: () => import("@/views/maxView"),
    redirect:"/HomeView",
    children: [
      { path: "/HomeView", component: () => import("@/views/HomeView") },
      { path: "/AboutView", component: () => import("@/views/AboutView") },
      { path: "/myView", component: () => import("@/views/myView") }
    ]
  }
]

const router = new VueRouter({
  routes
})

export default router
