<template>
  <div class="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "VueAppApp",

  data() {
    return {};
  },

  mounted() {},

  methods: {},
};
</script>

<style lang="scss" >
  *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    list-style: none;
  }
</style>
