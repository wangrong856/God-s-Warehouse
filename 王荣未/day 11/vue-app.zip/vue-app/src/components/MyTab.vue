<template>
  <div class="mytab">
    <table border=".6" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th>#</th>
          <th>商品名称</th>
          <th>价格</th>
          <th>标签</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(t, i) in arr" :key="t.goods_id" class="tr">
          <td width="40">{{ i + 1 }}</td>
          <td class="td">{{ t.goods_name }}</td>
          <td width="60">{{ t.goods_price }}</td>
          <td width="150">
            <slot :t="t" :i="i" name="tagSlot"></slot>
          </td>
          <td>
            <slot :t="t" name="delBtn"> </slot>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: "VueAppMyTab",

  data() {
    return {};
  },

  props: {
    arr: Array,
  },

  mounted() {},

  methods: {},
};
</script>

<style lang="scss" scoped>
.mytab {
  margin-bottom: 4.25rem;
}
table {
  border: 0.0625rem solid #ccc;
  .tr {
    .td {
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
    }
    td {
      line-height: 2.5rem;
      font-size: 0.8rem;
      padding-left: 0.3125rem;
      .tag {
        font-size: 0.75rem;
        border-radius: 0.1875rem;
        width: 2.5rem;
        height: 1.4375rem;
        background: rgb(58, 121, 246);
        text-align: center;
        line-height: 1.4375rem;
        color: #fff;
        margin: 0.4375rem 0;
        margin-bottom: 0.1875rem;
        cursor: pointer;
      }
      .inp {
        margin: 0.4375rem 0;
        margin-bottom: 0.1875rem;
        height: 1.4375rem;
        text-align: left;
        line-height: 1.437rem;
        input {
          width: 4.0625rem;
          height: 1.4375rem;
          border: 0.0625rem solid rgb(196, 220, 252);
          border-radius: 0.1875rem;
        }
      }
      .box-tag {
        width: 100%;
        height: 100%;
        display: flex;
        flex-wrap: wrap;
        span {
          //   width: 2.125rem;
          height: 1.125rem;
          display: inline-block;
          text-align: center;
          font-weight: 600;
          line-height: 1.125rem;
          margin: 0.1875rem 0.3125rem;
          font-size: 0.625rem;
          border-radius: 0.3125rem;
          background: rgb(244, 195, 68);
          padding: 0 0.3125rem;
        }
      }
    }
    .delBtn {
      width: 2.875rem;
      height: 1.6625rem;
      font-size: 0.8125rem;
      color: #fff;
      background: rgb(202, 68, 74);
      border-radius: 0.15rem;
      border: none;
      font-weight: 300;
      cursor: pointer;
    }
  }
}
</style>
