<template>
  <div class="tabSwitch">
    <div class="foot">
      <ul>
        <li v-for="(t, i) in tabList" :key="i">
          <div class="box-li" @click="tabSwitch(t, i)">
            <img :src="active !== i ? t.imags : t.selectImags" />
            <span :style="{color:active == i ? 'rgb(98, 157, 247)' : '#000'}">{{ t.name }}</span>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: "VueAppTabSwitch",

  data() {
    return {
      tabList: [
        {
          name: "商品列表",
          imags: "/images/WechatIMG962.png",
          selectImags: "/images/WechatIMG965.png",
          path: "/",
        },
        {
          name: "商品搜素",
          imags: "/images/WechatIMG963.png",
          selectImags: "/images/WechatIMG964.png",
          path: "/AboutView",
        },
        {
          name: "我的信息",
          imags: "/images/WechatIMG961.png",
          selectImags: "/images/WechatIMG966.png",
          path: "/myView",
        },
      ],
      active: 0,
    };
  },

  mounted() {},

  methods: {
    tabSwitch(t, i) {
      this.active = i;
      this.$router.push(t.path).catch((err) => err);
    },
  },
};
</script>

<style lang="scss" scoped>
.foot {
  width: 100%;
  height: 3.125rem;
  border: 0.0625rem solid #f4f4f4;
  position: fixed;
  bottom: 0;
  margin: auto;
  background: #fff;
  z-index: 999;
  ul {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-around;
    li {
      width: 33.33%;
      .box-li {
        width: 100%;
        height: 100%;
        text-align: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-decoration: none;
        color: #000;
        cursor: pointer;
        img {
          width: 1.225rem;
          height: 1.225rem;
        }
        span {
          font-size: 0.8375rem;
        }
      }
    }
  }
}
</style>
