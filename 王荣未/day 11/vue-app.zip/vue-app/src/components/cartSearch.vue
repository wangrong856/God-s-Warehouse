<template>
    <div class="VueAppCartSearch">
        
    </div>
</template>

<script>
export default {
    name: 'VueAppCartSearch',

    data() {
        return {
            
        };
    },

    mounted() {
        
    },

    methods: {
        
    },
};
</script>

<style lang="scss" scoped>

</style>