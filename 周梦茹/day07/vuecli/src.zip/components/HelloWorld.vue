<template>
  <div class="hello">
      <h3>HelloWorld</h3>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  }
}
</script>


<style scoped lang="scss">

</style>
