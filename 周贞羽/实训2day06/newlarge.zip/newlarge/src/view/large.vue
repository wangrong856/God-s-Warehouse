<template>
  <div class="large">
    <div class="viewport">
      <!-- 小佐盒子 -->
      <div class="column">
        <!-- 小盒子1.1 -->
        <div class="conal">
          <!-- 小小盒子 -->
          <div class="inner">
            <ul>
              <li>
                <p class="innerps">2,190</p>
                <span class="equipment">
                  <div class="icon-dot"></div>
                  设备总数
                </span>
              </li>
              <li>
                <p class="innerps">190</p>
                <span class="equipment">
                  <div class="icon-dot" style="color: #65cea7"></div>
                  季度新增
                </span>
              </li>
              <li>
                <p class="innerps">3,001</p>
                <span class="equipment">
                  <div class="icon-dot" style="color: #65cea7"></div>
                  运营设备
                </span>
              </li>
              <li>
                <p class="innerps">108</p>
                <span class="equipment">
                  <div class="icon-dot" style="color: #e2362d"></div>
                  异常设备
                </span>
              </li>
            </ul>
          </div>
        </div>

        <!-- 故障设备监控1.2 -->
        <div class="allllll">
          <div class="conal Unreachable">
            <!-- 1.2小小盒子 -->
            <div class="inner">
              <!-- 标题 -->
              <div class="titles">
                <div class="head">
                  <a href="javascript:;">故障设备监控</a>
                  <a href="javascript:;">异常设备监控</a>
                </div>
              </div>
              <!-- 内容 -->
              <div class="content">
                <div class="content_son">
                  <!-- 内容标签 -->
                  <div class="content_title">
                    <a href="javascript:;">故障时间</a>
                    <a href="javascript:;">设备地址</a>
                    <a href="javascript:;">异常代码</a>
                  </div>
                  <!-- all -->
                  <div class="view">
                    <div class="all">
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                      <div class="bottomcontent">
                        <div class="allcontent">
                          <a href="javascript:;">20190601</a>
                          <a href="javascript:;"
                            >北京市昌平区城西路金燕龙写字楼</a
                          >
                          <a href="javascript:;">1000002</a>
                          <span class="icon-dot"></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="conals cakehe">
          <!-- 小小盒子 -->
          <div class="inners">
            <!-- 饼图 -->
            <pie-view></pie-view>
            <ul>
              <li>
                <p class="innerps">320,11</p>
                <span class="equipment">
                  <div class="red_cake"></div>
                  点位总数
                </span>
              </li>
              <li>
                <p class="innerps">418</p>
                <span class="equipment">
                  <div class="yellow_cake"></div>
                  本月新增
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!-- 小中盒子 -->
      <div class="column">
        <div class="middle">
          <span>设备数据统计</span>
          <div class="middle_all">
            <div class="middle_top"></div>
            <div class="conal Columnar">
              <!-- 小小盒子 -->
              <div class="inner">
                <div class="span">全国用户总量统计</div>
                <div class="allmiddle">
                  <!-- 柱形图 -->
                  <clou-view></clou-view>
                  <div class="rightmiddle">
                    <div class="divs">
                      <span>120,899</span>
                      <div class="redyellow">
                        <div class="icon-dot" style="color: #e33835"></div>
                        用户总量
                      </div>
                    </div>
                    <div class="divs">
                      <span>120,899</span>
                      <div class="redyellow">
                        <div class="icon-dot" style="color: #dfca18"></div>
                        本月新增
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 小右盒子 -->
      <div class="column">
        <div class="column_sonsn">
          <!--右 上1.1 -->
          <div class="conal Columnar threecolmn">
            <!-- 小小盒子 -->
            <div class="inner">
              <div class="threesixfive">
                <div class="fivesix"></div>
              </div>
            </div>
          </div>
          <!-- 1.2 -->
          <div class="conal Columnar threecomsync">
            <!-- 小小盒子 -->
            <div class="inner">
              <div class="salesvolume">
                <span class="Sales">销售额统计</span>
                <div class="titlea">
                  <a href="javascript:;">年</a>
                  <a href="javascript:;">季</a>
                  <a href="javascript:;">月</a>
                  <a href="javascript:;">周</a>
                </div>
              </div>
            </div>
          </div>
          <!-- 1.3两个的 -->
          <div class="two_column">
            <div class="conal Columnar threecomsy">
              <!-- 小小盒子 -->
              <div class="inner"></div>
            </div>
            <div class="conal Columnar threecomsy">
              <!-- 小小盒子 -->
              <div class="inner">
                <div class="cale">
                  <five-view></five-view>
                </div>
                <div class="cale_bottom">
                  <div class="leftdiv">
                    <span>1,321</span>
                    <div class="xwcake">
                      <div class="icon-dot" style="color: #6acca3"></div>
                      销售额(万元)
                    </div>
                  </div>
                  <div class="leftdiv">
                    <span>150%</span>
                    <div class="xwcake">
                      <div class="icon-dot" style="color: #e2362d"></div>
                      同比增长
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import * as echarts from "echarts";
// 引入饼图
import PieView from "./son/PieView.vue";
// 引入柱形图
import ClouView from "./son/ColuView.vue";
// 引入半圆
import FiveView from "./son/FiveView.vue";
export default {
  components: {
    PieView,
    ClouView,
    FiveView,
  },
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>

<style>
</style>