<template>
  <div class="five">
    <div id="calesync" style="background-color: transparent; width: 300px; height: 125px;"></div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
    mounted(){
        var myChartync = echarts.init(document.getElementById('calesync'));//50%
        let optionse = {
        title: {
            text: "一季度销售进度",
            left: -10,
            top: 0,
            textStyle: {
                fontSize: 16,
                color:'#fff',
                fontWeight:100,
            }
        },
        tooltip: {
            trigger: 'item'
        },
        series: [
            {
                silent:true,
                name: 'Access From',
                type: 'pie',
                center:['35%','80%'],
                radius: ['70%', '85%'],
                avoidLabelOverlap: false,
                label: {
                    show: true,
                    position: 'center',
                },
                emphasis: {
                    // disabled:true,//高亮禁用关闭
                    scale: false,//高亮扇形放大效果
                    label: {
                        show: true,
                        fontSize: 100,
                        fontWeight: 'bold'
                    }
                },
                labelLine: {
                    show: true
                },
               
                data: [
                    {
                        value: 10,
                        name: "50%",
                        itemStyle: {
                            color: {
                                type: 'linear',
                                x: 0,
                                y: 0,
                                x2: 0,
                                y2: 1,
                                colorStops: [{
                                    offset: 0, color: '#12274d' // 0% 处的颜色
                                }, {
                                    offset: 1, color: '#12274d' // 100% 处的颜色
                                }],
                                global: false // 缺省为 false
                            }
                        }

                    },
                    {
                        value: 20, itemStyle: {
                            color: 'transparent'
                        }
                    },
                    {
                        value: 10, name: "50%", itemStyle: {
                            color: {
                                type: 'linear',
                                x: 0,
                                y: 0,
                                x2: 0,
                                y2: 1,
                                colorStops: [{
                                    offset: 0, color: '#00c0dd' // 0% 处的颜色
                                }, {
                                    offset: 1, color: '#005cba' // 100% 处的颜色
                                }],
                                global: false // 缺省为 false
                            }
                        }
                    },

                ]
            }
        ]
    };
    myChartync.setOption(optionse);
    }
}
</script>

<style>

</style>