<template>
  <div class="pie">
    <div id="cakeso" style="width: 200px; height: 300px;"></div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  mounted(){
    var myChart = echarts.init(document.getElementById('cakeso'));
    let option={
        title: {
            text: "点位分布统计",
            top: "5",
            left: '5',
            bottom: "10",
            textStyle: {
                color: "#fff",

            }
        },
        legend: {
            show: false,
        },
        toolbox: {
            show: true,
        },
        color: ['#006cff', '#60cda0', '#ed8884', '#ff9f7f', '#0096ff', '#9fe6b8', '#32c5e9', '#1d9dff'],
        series: [
            {
                labelLine: {
                    length: 10,
                    length2: 3
                },
                silent: true,
                name: 'Nightingale Chart',
                type: 'pie',
                radius: [10, 40],
                center: ['50%', '50%'],
                roseType: 'radius',
                itemStyle: {
                    borderRadius: 0
                },
                data: [
                    { value: 18, name: '云南' },
                    { value: 22, name: '北京' },
                    { value: 22, name: '山东' },
                    { value: 26, name: '河北' },
                    { value: 28, name: '江苏' },
                    { value: 30, name: '浙江' },
                    { value: 32, name: '四川' },
                    { value: 38, name: '河北' },
                ]
            }
        ]
      }
    myChart.setOption(option);
  },
  methods:{
   
  }
}
</script>

<style>

</style>