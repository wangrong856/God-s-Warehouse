<template>
  <div class="coluview">
    <div id="Columnars" style="width: 550px; height: 250px;"></div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
    mounted(){
        var myCharty = echarts.init(document.getElementById('Columnars'));
        let item = {
        name: "",
        value: 55,
        itemStyle: {
            color: "#254065",//图形的颜色
        },
    },
        options = {
            xAxis: {
                axisTick: false,//是否显示坐标轴的刻度
                type: 'category',
                data: ['北京', '上海', '广东', '广州', '广西', '', '......', '', '新疆', '黑龙江',
                    '吉林', '河南', '河北', '哈尔滨', '三亚'],
                show: true,
                axisLine: {
                    lineStyle: {
                        color: "#005b70",
                    }
                }
            },
            grid: {
                show: true,
                borderColor: '#005b70'
            },
            yAxis: {
                axisLine: {
                    lineStyle: {
                        color: '#214a81'
                    }
                },
                axisPointer: {
                    show: true,
                    label: {
                        color: "red",
                        fontSize: 30
                    },
                },

                type: 'value',
                splitLine: {
                    lineStyle: {
                        color: '#00425a'
                    }
                }
            },
            series: [
                {
                    data: [120, 200, 150, 80, 70, item, item, item, 200, 150, 80, 70, 110, 130, 199],
                    type: 'bar',
                    color: {
                        type: 'linear',
                        x: 0,
                        y: 0,
                        x2: 0,
                        y2: 1,
                        colorStops: [{
                            offset: 0, color: '#00e8f4' // 0% 处的颜色
                        }, {
                            offset: 1, color: '#0062cb' // 100% 处的颜色
                        }],
                        global: false // 缺省为 false
                    }
                }
            ]
        };
    myCharty.setOption(options);
    window.addEventListener('selet', function () {
        myCharty.selet()
    })
    }
}
</script>

<style>

</style>