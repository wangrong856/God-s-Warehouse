import Vue from 'vue'
import App from './App.vue'
import router from './router'
// 引入全局样式
import '@/css/commit.css'
// 引入全局自适应样式
import './js/flexible'
Vue.config.productionTip = false
new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
